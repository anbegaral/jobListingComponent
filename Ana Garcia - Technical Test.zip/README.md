# jobListingComponent

For this project, I have chosen AngularJS v.1.6.6 to implement this solution. As the project is not complex, this version of Angular is very adequate, because is easy to implement and really light.

